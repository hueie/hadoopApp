package ledger.index.service;

import ledger.index.model.IndexVO;

public interface IndexService {
	public void IndexInsert(IndexVO indexVO);
}
