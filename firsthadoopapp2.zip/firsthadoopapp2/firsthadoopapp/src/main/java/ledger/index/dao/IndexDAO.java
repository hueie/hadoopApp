package ledger.index.dao;

import ledger.index.model.IndexVO;

public interface IndexDAO {
	void IndexInsert(IndexVO indexVO);
}
